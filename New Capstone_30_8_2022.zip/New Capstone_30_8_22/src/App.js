import React from "react";
import { BrowserRouter as Router,Routes, Route } from "react-router-dom";
import './App.css';
import Navbar from "./Components/Navbar/Navbar";
import Products from "./Components/Products/products";
import Contact from "./Components/Contact/contact";
import AboutUs from "./Components/AboutUs/aboutus";
import ProductInfo from "./Components/ProductInfo/ProductInfo";
import Home from "./Components/Home/home";

function App() {
  return (
    <Router>
      <Navbar />
  <Routes>
      <Route path="/" element={<Home/>} exact />
      <Route path="/products" element={<Products/>} />
      <Route path="/aboutus" element={<AboutUs/>}exact />
      <Route path="/contact" element={<Contact/>} />
      <Route path="/productInfo/:id" element={<ProductInfo/>} exact />
      </Routes>
    </Router>

  );
}

export default App;
