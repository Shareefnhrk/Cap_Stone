import { render, screen } from "@testing-library/react";

import { createMemoryHistory } from "history";
import React from "react";
import { BrowserRouter as Router, Switch, useLocation } from "react-router-dom";
import "@testing-library/jest-dom";
import App from "./App";

test("full app rendering navigation ", () => {
  const history = createMemoryHistory();

  render(
    
     // <Router location={history.location} navigator={history}>
        <App />
      //</Router>

  );
});
