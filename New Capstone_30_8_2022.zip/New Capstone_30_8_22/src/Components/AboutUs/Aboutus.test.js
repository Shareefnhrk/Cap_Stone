import AboutUs from "./AboutUs";
import { getByText, render, screen } from "@testing-library/react";

describe("test", () => {


    test("testing AboutUs Component ", async () => {
        render(
            <AboutUs />
        );

        const history = screen.getByTestId("history")
        expect(history).toBeInTheDocument()
        expect(history).toHaveTextContent("HISTORY")
    });

})