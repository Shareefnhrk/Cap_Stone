import React from "react";
import ReactDOM from "react-dom";
import ImageSlider from "./ImageSlider";
import renderer from "react-test-renderer";

describe("test CAROUSEL component", () => {
  test("should render carousel with text ", () => {
    const tree = renderer
      .create(
        <ImageSlider
          slides={[
            "../assets/Product1.png",
            "../assets/Product2.png",
            "../assets/Product3.png",
            "../assets/Product4.png",
          ]}
        
        />
      )
      .toJSON();
    expect(tree).toMatchSnapshot;
  });
});
