import Contact from "./Contact";
import { render, screen } from "@testing-library/react";


import userEvent from "@testing-library/user-event";


describe("TEST CONTACT PAGE", () => {
  

  test("testing name in contact form Component ", async () => {
    const { getByTestId, getByPlaceholderText } = render(
      
        <Contact />
    
    );

    const nameId = getByPlaceholderText(/Your Name/i);
    const emailId = getByPlaceholderText(/Your email/i);
    const phoneId = getByPlaceholderText(/Your Phone Number/i);
    const messageId = getByPlaceholderText(/Message/i);

    expect(nameId).toBeInTheDocument();
    expect(emailId).toBeInTheDocument();
    expect(phoneId).toBeInTheDocument();
    expect(messageId).toBeInTheDocument();

    userEvent.type(nameId, "sampleName");
    userEvent.type(emailId, "sample@gmail.com");
    userEvent.type(phoneId, "1234567890");
    userEvent.type(messageId, "testing message field");


    expect(screen.getByTestId("name")).toHaveValue("sampleName");
    expect(screen.getByTestId("email")).toHaveValue("sample@gmail.com");
    expect(screen.getByTestId("phone")).toHaveValue(1234567890);
    expect(screen.getByTestId("message")).toHaveValue("testing message field");

    const submitButton = getByTestId("submitBtn");

    expect(submitButton).toBeInTheDocument();

    userEvent.click(submitButton);

    fetch("http://localhost:5001/getInTouchData",{
        method: "POST",
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: {},
    }).then((res) => {
      
        

      expect({}).toEqual(res);
    });
  });
});
