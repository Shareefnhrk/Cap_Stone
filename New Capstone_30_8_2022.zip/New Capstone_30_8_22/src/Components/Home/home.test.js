import React from "react";
import Home from "./home";


describe("TEST HOMEPAGE TEST", () => {
 

  test("should render homepage with text", () => {
    expect(
    
        <Home />
      
    ).toMatchSnapshot;
  });
});
