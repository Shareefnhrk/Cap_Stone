import React, { useEffect, useState } from "react";
import { useLocation, Link  } from "react-router-dom";
//React icons
import * as FaIcons from "react-icons/fa";
import { BsX } from "react-icons/bs";
import "./Navbar.scss";

function Navbar() {
  const location = useLocation();
  const [show, handleShow] = useState(false);
  const [sidebar, setSidebar] = useState(false);

  const showSidebar = () => setSidebar(!sidebar);
 
  useEffect(() => {
    window.addEventListener("scroll", () => {
      if (window.scrollY > 100) {
        handleShow(true);
      } else {
        handleShow(false);
      }
    });
  }, []);
  
  return (
    <nav
      style={{ position: "sticky" }}
      className={
        location.pathname === "/productInfo"
          ? sidebar
            ? "navbar  navbar-light sticky-top  nav-menu active scroll"
            : "navbar  navbar-light sticky-top scroll"
          : show
          ? sidebar
            ? "navbar  navbar-light sticky-top  nav-menu active scroll"
            : "navbar  navbar-light sticky-top scroll"
          : sidebar
          ? "navbar  navbar-light sticky-top  nav-menu active noscroll"
          : "navbar   sticky-top noscroll"
      }
    >
      <Link to="#" className="menu-bars">
        {!sidebar ? (
          <FaIcons.FaBars style={{ color: "red" }} onClick={showSidebar} />
        ) : (
          <BsX onClick={showSidebar} className="nav-close" />
        )}
      </Link>

      {sidebar ? (
        ""
      ) : (
        <a href="/" >
          <img src="assets/images/LOGO.jpg" className="imgClass" alt="logo" />
        </a>
      )}
      <ul class={sidebar ? "nav flex-column nav-i" : "nav justify-content-end"}>
        <li class="nav-item">
          <Link
            to="/"
            class={location.pathname === "/" ? "nav-link link" : "nav-link"}
          >
            HOME
          </Link>
        </li>
        <li class="nav-item">
          <Link
            to="/products"
            class={location.pathname === "/products" ? "nav-link link" : "nav-link"}
          >
            Products
          </Link>
        </li>
        <li class="nav-item">
          <Link
            to="/aboutus"
            class={
              location.pathname === "/aboutus" ? "nav-link link" : "nav-link"
            }
          >
            ABOUT US
          </Link>
        </li>
        <li class="nav-item">
          <Link
            to="/contact"
            class={
              location.pathname === "/contact" ? "nav-link link" : "nav-link"
            }
          >
            CONTACT
          </Link>
        </li>
      </ul>
    </nav>
  );
}

export default Navbar;
