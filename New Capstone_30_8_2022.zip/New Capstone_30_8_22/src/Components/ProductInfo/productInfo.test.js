import { render, screen, fireEvent } from "@testing-library/react";

import ProductInfo from "./ProductInfo";
import React from "react";
import userEvent from "@testing-library/user-event";


describe("TEST ProductInfo PAGE", () => {
    test("MenuDetails render without crashing", () => {

        render(
            <ProductInfo />
        );
    });

    test("To check about the next button on the feedback model with data", () => {
        render(
            <ProductInfo/>
        );
        const name = screen.getByTestId("name");
        userEvent.type(name);


        const email = screen.getByTestId("email");
        userEvent.type(email);

        const phone = screen.getByTestId("phone");
        userEvent.type(phone);


        const textarea = screen.getByTestId("message");
        userEvent.type(textarea, "text area testing");

        const submit = screen.getByTestId("submit");
        userEvent.click(submit);
        expect(submit).toHaveTextContent("Submit")


    });

});
