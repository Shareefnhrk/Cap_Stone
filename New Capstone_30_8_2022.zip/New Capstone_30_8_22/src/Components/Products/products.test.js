import { render, screen } from "@testing-library/react";
import Products from "./products";



let item = [
    {
        "id": 1,
        "brand": "Roadster",
        "name": "Men Cotton Casual Shirt",
        "discountPrice": 674,
        "price": 1499,
        "discount": "55% OFF",
        "image": "Product1.png"
    },
    {
        "id": 2,
        "brand": "Dennis Lingo",
        "name": "Men Slim Casual Shirt",
        "discountPrice": 699,
        "price": 1849,
        "discount": "RS 1150 OFF",
        "image": "Product2.png"
    },
    {
        "id": 3,
        "brand": "WROGN",
        "name": "Men Slim Casual Shirt",
        "discountPrice": 1679,
        "price": 2399,
        "discount": "30% OFF",
        "image": "Product3.png"
    },
];

describe("Test product component", () => {
    test("render Card component and pass props to test", () => {
        render(
            <Products data={item} />
        );
    });
});
